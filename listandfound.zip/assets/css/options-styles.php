/* Typography
--------------------------*/
body {
  color:<?php echo do_shortcode('[acf field="field_611a2d10fa164" post_id="option"]'); ?>;
  font-size:<?php echo do_shortcode('[acf field="field_611a2d3ffa167" post_id="option"]'); ?>px;
  font-family:<?php echo do_shortcode('[acf field="field_611a2d33fa165" post_id="option"]'); ?>;
  line-height:<?php echo do_shortcode('[acf field="field_611a2d35fa166" post_id="option"]'); ?>;
}
 
h1,h2,h3,h4,h5,h6 {
  color:<?php echo do_shortcode('[acf field="default_headline_color" post_id="option"]'); ?>;
  font-family:<?php echo do_shortcode('[acf field="defaut_header_font_family" post_id="option"]'); ?>;
}
 
a {color:<?php echo do_shortcode('[acf field="default_link_color" post_id="option"]'); ?>;}
a:hover{color:<?php echo do_shortcode('[acf field="default_linkhover_color" post_id="option"]'); ?>;}
a:active{color:<?php echo do_shortcode('[acf field="default_linkactive_color" post_id="option"]'); ?>;}
a:focus{color:<?php echo do_shortcode('[acf field="default_linkfocus_color" post_id="option"]'); ?>;}
a:visited{color:<?php echo do_shortcode('[acf field="default_linkvisited_color" post_id="option"]'); ?>;}