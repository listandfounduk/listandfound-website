/* =================================================================
Table of Contents

- Burger menu SVG
- Nav fixed
- Nav hide on scroll
- Slick sliders
- Counters
- Hide invalid form message on click
- Popup
- Accordion

================================================================= */

/* =================================================================
BURGER MENU SVG
================================================================= */

const button = document.querySelector('.burger-menu');
 const menu = document.querySelector('.main-navigation');
 const body = document.querySelector('body');
 const html = document.querySelector('html');

button.addEventListener('click', () => {
  button.classList.toggle('-menu-open');
  menu.classList.toggle('-open');
  body.classList.toggle('lock-scroll');
  html.classList.toggle('lock-scroll');
})

/* =================================================================
NAV FIXED
================================================================= */

window.onscroll = function() {myFunction()};

var header = document.getElementById("header");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("fixed");
  } else {
    header.classList.remove("fixed");
  }
}

/* =================================================================
NAV HIDE ON SCROLL
================================================================= */

 // Hide Header on on scroll down
 var didScroll;
 var lastScrollTop = 0;
 var delta = 5;
 var navbarHeight = jQuery("header").outerHeight();
 
 jQuery(window).scroll(function (event) {
   didScroll = true;
 });
 
 setInterval(function () {
   if (didScroll) {
     hasScrolled();
     didScroll = false;
   }
 }, 250);
 
 function hasScrolled() {
   var st = jQuery(this).scrollTop();
 
   // Make sure they scroll more than delta
   if (Math.abs(lastScrollTop - st) <= delta)
   return;
 
   // If they scrolled down and are past the navbar, add class .nav-up.
   // This is necessary so you never see what is "behind" the navbar.
   if (st > lastScrollTop && st > navbarHeight) {
     // Scroll Down
     jQuery("header").addClass("nav-up");
   } else {
     // Scroll Up
     if (st + jQuery(window).height() < jQuery(document).height()) {
       jQuery("header").removeClass("nav-up");
     }
   }
 
   lastScrollTop = st;
 }
           //# sourceURL=pen.js

/* =================================================================
SLICK SLIDERS
================================================================= */
jQuery(document).ready(function(){
    jQuery('.slider-background').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-content',
        speed: 1000,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true
    });
  
    jQuery('.slider-content').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.slider-background',
        dots: false,
        prevArrow:'<span class="arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M13.891 17.418a.697.697 0 0 1 0 .979.68.68 0 0 1-.969 0l-7.83-7.908a.697.697 0 0 1 0-.979l7.83-7.908a.68.68 0 0 1 .969 0 .697.697 0 0 1 0 .979L6.75 10l7.141 7.418z"/></svg></span>',
        nextArrow:'<span class="arrow-next"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M13.25 10L6.109 2.58a.697.697 0 0 1 0-.979.68.68 0 0 1 .969 0l7.83 7.908a.697.697 0 0 1 0 .979l-7.83 7.908a.68.68 0 0 1-.969 0 .697.697 0 0 1 0-.979L13.25 10z"/></svg></span>',
        focusOnSelect: true,
        speed: 1000,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true
    });


    jQuery('.slider-gallery').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow:'<span class="arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M13.891 17.418a.697.697 0 0 1 0 .979.68.68 0 0 1-.969 0l-7.83-7.908a.697.697 0 0 1 0-.979l7.83-7.908a.68.68 0 0 1 .969 0 .697.697 0 0 1 0 .979L6.75 10l7.141 7.418z"/></svg></span>',
        nextArrow:'<span class="arrow-next"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M13.25 10L6.109 2.58a.697.697 0 0 1 0-.979.68.68 0 0 1 .969 0l7.83 7.908a.697.697 0 0 1 0 .979l-7.83 7.908a.68.68 0 0 1-.969 0 .697.697 0 0 1 0-.979L13.25 10z"/></svg></span>',
        fade: true,
        speed: 1000,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true
    });
    });



/* =================================================================
COUNTERS
================================================================= */

    jQuery( document ).ready( function() {
	
        jQuery(function () {
            "use strict";
        
            var counterUp = window.counterUp["default"]; // import counterUp from "counterup2"
        
            var $counters = jQuery(".counter");
        
            /* Start counting, do this on DOM ready or with Waypoints. */
            $counters.each(function (ignore, counter) {
                var waypoint = new Waypoint( {
                    element: jQuery(this),
                    handler: function() { 
                        counterUp(counter, {
                            duration: 3000,
                            delay: 16
                        }); 
                        this.destroy();
                    },
                    offset: 'bottom-in-view',
                } );
            });
    
        });
     });


/* =================================================================
HIDE INVALID FORM MESSAGE ON CLICK
================================================================= */

    jQuery(document).ready(function($) {
        // clear cf7 error msg on mouseover
            $(".wpcf7-form-control-wrap").click(function(){
                $obj = $("span.wpcf7-not-valid-tip",this);
                $obj.css('display','none');
            });
    });

/* =================================================================
POPUP
================================================================= */

    function founderPopup() {
        var popup = document.getElementById("popup");
      
        popup.classList.toggle("active");
    }

/* =================================================================
ACCORDION
================================================================= */

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}