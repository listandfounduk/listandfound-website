<?php
/* =================================================================
The template for displaying all pages
================================================================= */
get_header();
?>

<?php include "template-parts/page-builder.php" ?>

<?php
get_sidebar();
get_footer();