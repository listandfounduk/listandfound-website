<header class="site-header" id="header">
    <div class="inner-header">
        <a href="<?php echo do_shortcode('[acf field="field_61d46c29efcce" post_id="option"]'); ?>"><?php echo do_shortcode('[acf field="field_61d46c0eefccd" post_id="option"]'); ?></a>
<style>
    lottie-player {
        max-width:130px;
    }
</style>
	    <h1 class="site-title">

 <?php// if( get_field('field_617bb3e02e59d', 'option') ): ?>
    		    <a href="<?php echo get_home_url(); ?>">

                <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script><lottie-player src="/wp-content/themes/listandfound/assets/json/data.json" background="transparent" speed="1" loop autoplay></lottie-player>
                
				    <!-- <img src="<?php // the_field('field_617bb3e02e59d', 'option'); ?>" class="logo" alt="<?php // bloginfo( 'name' ); ?>" title="<?php // bloginfo( 'name' ); ?>" /> -->
			    </a>
		    <?php// endif; ?>
		    
	    </h1>



        <div class="burger-menu">
        <svg width="48px" height="48px" viewBox="0 0 48 48" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <g>
            <line x1="10" y1="17" x2="38" y2="17" stroke-width="6" stroke-linecap="round" />
            <line x1="10" y1="31" x2="38" y2="31" stroke-width="6" stroke-linecap="round" />
          </g>
          
          <g>
            <line x1="10" y1="24" x2="38" y2="24" stroke-width="6" stroke-linecap="round" />
            <line x1="10" y1="24" x2="38" y2="24" stroke-width="6" stroke-linecap="round" />
          </g>
        </svg>
      </div>
    
	     <nav class="main-navigation">
		    <?php
		    wp_nav_menu( array(
			    'theme_location' => 'menu-1',
			    'menu_id'        => 'primary-menu',
		    ) );
		    ?>
	    </nav> 
    </div>
</header>