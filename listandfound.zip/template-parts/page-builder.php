<?php
/* =================================================================
Table of contents
================================================================= 

- Hero Section Image Left
- Hero Section Image Right
- Standard Section Image Left
- Standard Section Image Right
- Full Width Slider
- Full Width Text
- Client Logos
- CTA - About us
- CTA Footer
- CTA - Single Line
- Case Study - Image Right
- Case Study - Image Left
- Our Services
- Services - Descriptions
    - Service - Image Left
    - Service - Image Right
- Industries
- Meet the team - Team member 
- Contact Form
- Maps
- Accordion

*/
?>

<?php if( have_rows('page_builder') ): ?>
    <?php while( have_rows('page_builder') ): the_row(); ?>
        <?php 

        // ======== Hero Section Image Left ========

            if( get_row_layout() == 'hero_left' ):
                $title = get_sub_field('field_61a8dd2b8ad3e');
                $subtitle = get_sub_field('field_61a8e5850b455');
                $content = get_sub_field('field_61aa38856d379');
                $image = get_sub_field('field_61a8dcc112782');

                $addbutton = get_sub_field('field_61a8dfbc3ab7a');
                $buttontext = get_sub_field('field_61a8dfee3ab7b');
                $buttonlink = get_sub_field('field_61a8e303caf5d');

                $layouttype = get_sub_field('field_61aa38166d378');

                // settings

                $margintop = get_sub_field('field_61bca8bba2912');
                $marginbottom = get_sub_field('field_61bca8e4a2913');
        ?>

            <section class="grid image-left gradient" style="<?php if( $margintop !==false ): ?>margin-top:<?php echo $margintop ?>px;<?php endif; ?><?php if( $marginbottom !==false ): ?>margin-bottom:<?php echo $marginbottom ?>px;<?php endif; ?>">

                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>

                <div class="content">
                    <div class="text-section">
                        <h1 style="margin-bottom:40px;"><?php echo $title ?></h1>
                        <?php if( $layouttype == 'title-subtitle' ) { ?>
                        <h1><?php echo $subtitle ?></h1>
                        <?php } ?>
                        <?php if( $layouttype == 'title-text' ) { ?>
                        <p><?php echo $content ?></>
                        <?php } ?>

                        <?php if( $addbutton == 'yes' ) { ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php } ?>
                    </div>

                    <div class="item-right width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

                </div>
            </section>

        <?php 

        // ======== Hero Section Image Right ========

            elseif( get_row_layout() == 'hero_right' ): 
                $title = get_sub_field('field_61a9e3fb6573b');
                $subtitle = get_sub_field('field_61a9e3fb6573c');
                $content = get_sub_field('field_61bcad9caf5e6');
                $image = get_sub_field('field_61a9e3fb6573e');

                $addbutton = get_sub_field('field_61a9e3fb65740');
                $buttontext = get_sub_field('field_61a9e3fb65741');
                $buttonlink = get_sub_field('field_61a9e3fb65742');

                $layouttype = get_sub_field('field_61bcad76af5e5');

                // settings

                $margintop = get_sub_field('field_61bcac82d5e8e');
                $marginbottom = get_sub_field('field_61bcac86d5e8f');
        ?>

            <section class="grid image-right gradient" style="<?php if( $margintop !==false ): ?>margin-top:<?php echo $margintop ?>px;<?php endif; ?><?php if( $marginbottom !==false ): ?>margin-bottom:<?php echo $marginbottom ?>px;<?php endif; ?>">

                <div class="content">
                    <div class="text-section">
                    <h2 style="margin-bottom:40px;"><?php echo $title ?></h2>
                    <?php if( $layouttype == 'title-subtitle' ) { ?>
                        <h2><?php echo $subtitle ?></h2>
                        <?php } ?>
                        <?php if( $layouttype == 'title-text' ) { ?>
                        <p><?php echo $content ?></>
                        <?php } ?>

                        <?php if( $addbutton == 'yes' ) { ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php } ?>
                    </div>
                    
                    <div class="item-left width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>

                </div>

                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>

            </section>

        <?php 

        // ======== Standard Section Image Left ========

            elseif( get_row_layout() == 'standard_left' ): 
                $title = get_sub_field('field_61a9ed6412708');
                $content = get_sub_field('field_61a8de18f2a87');
                $image = get_sub_field('field_61a8de18f2a88');

                $addbutton = get_sub_field('field_61a9ee6812709');
                $buttontext = get_sub_field('field_61a9ee711270a');
                $buttonlink = get_sub_field('field_61a9ee741270b');
        ?>
            <section class="grid image-left">
                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>
    
                <div class="content">
                    <div class="item-right width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                        
                    <div class="text-section">
                        <?php if( $title ) { ?>
                            <h3><?php echo $title ?></h3>
                        <?php } ?>

                        <?php echo $content ?>

                        <?php if( $addbutton == 'yes' ) { ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php } ?>
                    </div>
                        
                    <div class="item-right width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

                </div>
            </section>

        <?php 

        // ======== Standard Section Image Right ========

            elseif( get_row_layout() == 'standard_right' ): 
                $title = get_sub_field('field_61a9efc0a1a19');
                $content = get_sub_field('field_61a9efc0a1a1a');
                $image = get_sub_field('field_61a9efc0a1a1c');

                $addbutton = get_sub_field('field_61a9efc0a1a1e');
                $buttontext = get_sub_field('field_61a9efc0a1a1f');
                $buttonlink = get_sub_field('field_61a9efc0a1a20');
        ?>
            <section class="grid image-right">
                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>
    
                <div class="content">
                    <div class="item-left width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                        
                    <div class="text-section">
                        <?php if( $title ) { ?>
                            <h3><?php echo $title ?></h3>
                        <?php } ?>

                        <?php echo $content ?>

                        <?php if( $addbutton == 'yes' ) { ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php } ?>
                    </div>
                        
                    <div class="item-left width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>

                </div>
            </section>
            
        <?php 

        // ======== Full Width Slider ========

            elseif( get_row_layout() == 'full_width_slider' ): 
                $title = get_sub_field('field_61a8de3cf2a8d');
        ?>

            <section class="slider-wrap">

                <div class="item-right width-7 top-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                <div class="item-left width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                    
                <div class="slider-background-wrap">  
                    <?php if( have_rows('slides') ): ?>
                        <div class="slider-background">
                        
                        <?php while( have_rows('slides') ): the_row();
                            $backgroundimage = get_sub_field('field_61a8de9ff2a91');
                        ?>
        
                            <div style="background-image:linear-gradient(to right, rgba(255,255,255, 1), rgba(255,255,255, 0)), url(<?php echo $backgroundimage ?>);"></div>
        
                        <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div>     

                <div class="slider-content-wrap">
                    <div class="slider-content-position-wrap">
                        <h3><?php echo $title ?></h3>
                        
                        <?php if( have_rows('slides') ): ?>
    
                            <div class="slider-content">

                                <?php while( have_rows('slides') ): the_row(); 
                                    $clientlogo = get_sub_field('field_61a8de94f2a90');
                                ?>
                                    <div>
                                        <img src="<?php echo $clientlogo ?>" alt="Logo" />
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="item-right width-8 bottom-no-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="0" data-aos="slide-left"></div>
                <div class="item-left width-3 bottom-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="0" data-aos="slide-right"></div>
                            
            </section>

        <?php 

        // ======== Full Width Text ========

            elseif( get_row_layout() == 'full_width_text' ): 
                $contentbig = get_sub_field('field_61aa2ab0bfcd4');
                $contentsmall = get_sub_field('field_61b71b1adefcc');
                $contentsmalltitle = get_sub_field('field_61c3219e62b77');
                $smallbig = get_sub_field('field_61b71476defca');

                $addbutton = get_sub_field('field_61aa2ad0bfcd5');
                $buttontext = get_sub_field('field_61aa2ad2bfcd6');
                $buttonlink = get_sub_field('field_61aa2ad6bfcd7');

                // settings

                $margintop = get_sub_field('field_61bcaee53e0a6');
                $marginbottom = get_sub_field('field_61bcaef53e0a7');
        ?>

            <section class="full-width-wrap" style="<?php if( $margintop !==false ): ?>padding-top:<?php echo $margintop ?>px;<?php endif; ?><?php if( $marginbottom  !==false ): ?>padding-bottom:<?php echo $marginbottom ?>px;<?php endif; ?>">

                <?php if( $contentsmalltitle ): ?>
                    <h3 style="margin-bottom:30px"><?php echo $contentsmalltitle ?></h3>
                <?php endif; ?>

                <?php if( $smallbig == 'paragraph' ) { ?>
                    <?php echo $contentsmall ?>
                <?php } ?>

                <?php if( $smallbig == 'header' ) { ?>
                    <h3><?php echo $contentbig ?></h3>
                <?php } ?>

                <?php if( $addbutton == 'yes' ) { ?>
                    <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                <?php } ?>

            </section>

        <?php 

        // ======== Client Logos ========

            elseif( get_row_layout() == 'client_logos' ): 
                $content = get_sub_field('field_61aa2ab0bfcd4');
        ?>
            <section class="full-width-flex-wrap" style="gap:20px;">

            <?php if( have_rows('field_61b70e53cefa5') ): ?>
                        
                <?php while( have_rows('field_61b70e53cefa5') ): the_row();
                    $clientimage = get_sub_field('field_61b70e6ccefa6');
                ?>
                    <img src="<?php echo $clientimage ?>" class="award" alt="Award Logo" title="Award Logo" />
        
                <?php endwhile; ?>
            <?php endif; ?>

            </section>

        <?php 

        // ======== CTA - About us ========

            elseif( get_row_layout() == 'cta_one' ): 
                $image = get_sub_field('field_61b710b974d13');
                $content = get_sub_field('field_61b710da74d14');
        ?>

            <section class="grid image-left">
                <div class="image profile no-min-height-mobile no-padding-top-bottom-mobile">
                    <div class="item-right width-7 absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                    <div class="item-right width-3 absolute" data-aos-delay="75" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                    <div class="item-right width-10 absolute" data-aos-delay="100" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

                    <img src="<?php echo $image ?>" alt="image of chris" title="Chris" />
        
                    <div class="item-left width-10 bottom-no-offset absolute" data-aos-delay="125" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                </div>

                <div class="content no-min-height-mobile no-padding-bottom-mobile">
                    <div class="text-section">
                        <?php echo $content ?>
                    </div>
                </div>
            </section>

         <?php 

        // ======== CTA Footer ========

            elseif( get_row_layout() == 'cta_2' ): 
                $text = get_sub_field('field_61b86e2f65931');
                $image = get_sub_field('field_61b86e7465933');
        ?>

            <section class="grid image-left footer-cta">

                <div class="image profile no-min-height-mobile no-padding-top-bottom-mobile">

                    <div class="item-right width-7 absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                    <div class="item-right width-3 absolute" data-aos-delay="100" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

                    <img src="<?php echo $image ?>" alt="team member image" title="Get in touch" />
        
                    <div class="item-left width-10 absolute" data-aos-delay="125" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                </div>

                <div class="content no-min-height-mobile ">
                    <div class="text-section">
                        <h3><?php echo $text ?></h3>
                    </div>
                </div>
                
                <div class="item-right width-2 absolute" data-aos-delay="100" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left" style="min-height:50px;"></div>
            
            </section>

            <?php 

        // ======== CTA - Single Line ========

            elseif( get_row_layout() == 'cta_3' ): 
                $text= get_sub_field('field_61bb47e33936d');
        ?>

            <section class="single-line-cta">

                <div class="item-left width-2 bottom-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>

                <h3><?php echo $text ?></h3>

            </section>

        <?php 

        // ======== Case Study - Image Right ========

            elseif( get_row_layout() == 'case_study_-_image_left' ): 
                $title = get_sub_field('field_61b723722e7cc');
                $titlelink = get_sub_field('field_61b72710c63ec');
                $excerpt = get_sub_field('field_61b723872e7cd');

                $buttontext = get_sub_field('field_61b723bc2e7d0');
                $buttonlink = get_sub_field('field_61b723c32e7d1');

                $image = get_sub_field('field_61b727e1d6811');

                // settings

                $margintop = get_sub_field('field_61d598f8cbc69');
                $marginbottom = get_sub_field('field_61d5990acbc6a');
        ?>

            <section class="grid image-right case-study" style="<?php if( $margintop !==false ): ?>margin-top:<?php echo $margintop ?>px;<?php endif; ?><?php if( $marginbottom !==false ): ?>margin-bottom:<?php echo $marginbottom ?>px;<?php endif; ?>">
                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>
                <div class="item-right width-7 top-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left" style="min-height: 50px;"></div>
                <div class="content" style="<?php if( $buttonlink ): ?><?php else : ?>padding-top:200px;padding-bottom:200px;<?php endif; ?>">
                    <div class="item-left width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                    <div class="text-section">
                    <h4>Case Study:</h4>
                        <h2><a href="<?php echo $titlelink ?>"><?php echo $title ?></a></h2>
                        <p style="margin-top:30px;"><?php echo $excerpt ?></p>

                        <?php if( $buttonlink ): ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php endif; ?>
                    </div>

                    <div class="item-left width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                </div>
            </section>

        <?php if( have_rows('field_61c328b642142') ): ?>
            <section class="case-studies-stats-wrap">
                        
                <?php while( have_rows('field_61c328b642142') ): the_row(); 

                    $stat = get_sub_field('field_61c328f242143');
                    $stattext = get_sub_field('field_61c328ff42144');
                    $statsize = get_sub_field('field_61c3290b42145');

                ?>

                    <div class="item-right stats-bar" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left" style="width:<?php echo $statsize ?>%">
                        <h3 class="counter"><?php echo $stat ?></h3>
                        <p><?php echo $stattext ?></p>
                    </div>
                
                <?php endwhile; ?>

            </section>
        <?php endif; ?>

        <?php 

        // ======== Case Study - Image Left ========

            elseif( get_row_layout() == 'case_study_-_image_right' ): 
                $title = get_sub_field('field_61b73bdf7bd2d');
                $titlelink = get_sub_field('field_61b73bdf7bd2e');
                $excerpt = get_sub_field('field_61b73bdf7bd2f');

                $buttontext = get_sub_field('field_61b73bdf7bd31');
                $buttonlink = get_sub_field('field_61b73bdf7bd32');

                $image = get_sub_field('field_61b73bdf7bd34');

                // settings

                $margintop = get_sub_field('field_61d599c8cbc6f');
                $marginbottom = get_sub_field('field_61d599d9cbc70');
        ?>

            <section class="grid image-left case-study" style="<?php if( $margintop !==false ): ?>margin-top:<?php echo $margintop ?>px;<?php endif; ?><?php if( $marginbottom !==false ): ?>margin-bottom:<?php echo $marginbottom ?>px;<?php endif; ?>">
                <div class="image" style="background-image:url(<?php echo $image ?>);"></div>
                
                <div class="content" style="<?php if( $buttonlink ): ?><?php else : ?>padding-top:200px;padding-bottom:200px;<?php endif; ?>">
                    <div class="item-right width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                    <div class="text-section">
                    <h4>Recent Project</h4>
                        <h2><a href="<?php echo $titlelink ?>"><?php echo $title ?></a></h2>
                        <p style="margin-top:30px;"><?php echo $excerpt ?></p>

                        <?php if( $buttonlink ): ?>
                            <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                        <?php endif; ?>
                    </div>

                    <div class="item-right width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                </div>
            </section>

        <?php if( have_rows('field_61c45eb6898d7') ): ?>
            <section class="case-studies-stats-wrap">
                        
                <?php while( have_rows('field_61c45eb6898d7') ): the_row(); 

                    $stat = get_sub_field('field_61c45eb6898d8');
                    $stattext = get_sub_field('field_61c45eb6898d9');
                    $statsize = get_sub_field('field_61c45eb6898da');

                ?>

                    <div class="item-left stats-bar" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right" style="width:<?php echo $statsize ?>%">
                        <h3 class="counter"><?php echo $stat ?></h3>
                        <p><?php echo $stattext ?></p>
                    </div>
                
                <?php endwhile; ?>

            </section>
        <?php endif; ?>

        <?php 

        // ======== Our Services ========

            elseif( get_row_layout() == 'our_services' ): 
                $text = get_sub_field('field_61b76e1309692');

                $buttontext = get_sub_field('field_61b76ed609698');
                $buttonlink = get_sub_field('field_61b76ede09699');
        ?>

            <section class="full-width-flex-wrap services">

                <div class="item-left width-3 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>

                <div class="services-button-wrap">
                    <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                </div>

                <?php if( have_rows('field_61b76e6409694') ): ?>
                    <div class="services-links-wrap">
                        
                        <?php $delay = 0;
                        
                        while( have_rows('field_61b76e6409694') ): the_row(); 

                            $servicetext = get_sub_field('field_61b76ea809695');
                            $servicelink = get_sub_field('field_61b76eae09696');
                        ?>
                            <a href="<?php echo $servicelink ?>" class="btn circle" data-aos="fade-right" data-aos-delay="<?php echo $delay ?>00"><span class="text-bg"></span><span class="text"><?php echo $servicetext ?></span></a>
                
                        <?php $delay++; endwhile; ?>
                    </div>
                <?php endif; ?>

                <div class="services-text-wrap">
                    <h3><?php echo $text ?></h3>
                </div>

                <div class="item-left width-1 bottom-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                <div class="item-right width-2 bottom-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

            </section>

        <?php 

        // ======== Services - Descriptions ========

            elseif( get_row_layout() == 'services_descriptions' ): 
                $title = get_sub_field('field_61b88d5c6bf90');
                $text = get_sub_field('field_61b88d686bf91');
        ?>

            <section class="full-width-wrap services-desc">
                <h3><?php echo $title ?></h3>
            
                <p style="margin-top:30px;padding:0 10%;"><?php echo $text ?></p>

            <?php if( have_rows('services_description_blocks') ): ?>
                <?php while( have_rows('services_description_blocks') ): the_row(); ?>

                    <?php 

                        // ======== Service - Image Right ========

                        if( get_row_layout() == 'service_image_right' ):
                            $title = get_sub_field('field_61b890476bf95');
                            $text = get_sub_field('field_61b8ab496bfa1');

                            $iconortext = get_sub_field('field_61b890576bf97');
                            $texticon = get_sub_field('field_61b890506bf96');
                            $icon = get_sub_field('field_61b8aac66bf9e');

                            $buttontext = get_sub_field('field_61b8ab296bfa0');
                            $buttonlink = get_sub_field('field_61b8ab136bf9f');
                    ?>

                        <div class="flex step-right-wrap">
                            <div class="item-left width-5 top-no-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                            <div class="step-left">
                                <h3 style="margin-bottom:30px;margin-left:1px;"><?php echo $title ?></h3>

                                <?php echo $text ?>

                                <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                            </div>
        
                            <div class="step-right">
                                <div class="services-icon-wrap" data-aos="fade-left">
                                    <span class="text-bg"></span>
                                    <span class="text">
                                        <?php if( $iconortext == 'text_icon' ) { ?>
                                            <?php echo $texticon ?>
                                        <?php } ?>

                                        <?php if( $iconortext == 'icon' ) { ?>
                                            <img src="<?php echo $icon ?>" />
                                        <?php } ?>
                                    </span>
                                </div>
                            </div>
                        </div>


                    <?php 

                        // ======== Service - Image Left ========

                        elseif( get_row_layout() == 'service_image_left' ): 
                            $title = get_sub_field('field_61b8abcb6bfa5');
                            $text = get_sub_field('field_61b8abcb6bfa6');

                            $iconortext = get_sub_field('field_61b8abcb6bfa8');
                            $text = get_sub_field('field_61b8abcb6bfa6');
                            $icon = get_sub_field('field_61b8abcb6bfaa');

                            $buttontext = get_sub_field('field_61b8abcb6bfac');
                            $buttonlink = get_sub_field('field_61b8abcb6bfad');
                    ?>

                        <div class="flex step-left-wrap">
                            
                            <div class="step-left">
                                <div class="services-icon-wrap" data-aos="fade-right">
                                    <span class="text-bg"></span>
                                    <span class="text">
                                        <?php if( $iconortext == 'text_icon' ) { ?>
                                            <?php echo $texticon ?>
                                        <?php } ?>
                                        
                                        <?php if( $iconortext == 'icon' ) { ?>
                                            <img src="<?php echo $icon ?>" />
                                        <?php } ?>
                                    </span>
                                </div>
                            </div>

                            <div class="item-right width-5 top-no-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>

                            <div class="step-right">
                                <h3 style="margin-bottom:30px;"><?php echo $title ?></h3>

                                <?php echo $text ?>

                                <a href="<?php echo $buttonlink ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></a>
                            </div>
                        </div>
                       
                    <?php endif; ?>
                <?php endwhile; ?>
            <?php endif; ?>
                
            </section>

        <?php 

            // ======== Industries ========

                elseif( get_row_layout() == 'industries_we_work_with' ): 
                    $title = get_sub_field('field_61bb30c89c0f7');
                    $textabove = get_sub_field('field_61bb30ce9c0f8');
                    $textbelow = get_sub_field('field_61bb30e69c0f9');
        ?>

            <section class="full-width-wrap">

                <h3><?php echo $title ?></h3>
                <p style="margin-top:30px;"><?php echo $textabove ?></p>

            <?php if( have_rows('field_61bb30fd9c0fb') ): ?>

                <div class="industry-cards">

                    <?php $delay = 0;
                        
                        while( have_rows('field_61bb30fd9c0fb') ): the_row(); 

                        $industry = get_sub_field('field_61bb310f9c0fc');
                    ?>

                        <div class="card" data-aos="fade-right" data-aos-delay="<?php echo $delay ?>00">
                            <span class="text-bg"></span>
                            <span class="text">
                                <?php echo $industry ?>
                            </span>
                        </div>
                    <?php $delay++; endwhile; ?>
                </div>
            <?php endif; ?>

                <p style="margin-top:30px;"><?php echo $textbelow ?></p>

            </section>

        <?php 

        // ======== Meet the team - Team member ========

            elseif( get_row_layout() == 'meet_the_team_team_member' ): 
                $leftrightimage = get_sub_field('field_61bc6dbffbd0e');

                $name = get_sub_field('field_61bc5d3545f51');
                $jobtitle = get_sub_field('field_61bc5d3c45f52');
                $description = get_sub_field('field_61bc5d4445f53');

                $image = get_sub_field('field_61bc5eaf57e86');

                $addabutton = get_sub_field('field_61bc5d6645f55');
                $buttontext = get_sub_field('field_61bc5d9045f56');
                $buttonlink = get_sub_field('field_61bc5da345f57');
        ?>
<style>
.image-left .image.profile {
    order:1;
}
.image-right .image.profile {
    order:2;
}
    </style>
            <section class="grid <?php if( $leftrightimage == 'imageleft' ) { ?>image-left<?php } ?> <?php if( $leftrightimage == 'imageright' ) { ?>image-right<?php } ?>">
                <div class="image profile no-min-height-mobile no-padding-top-bottom-mobile">
                    <div class="<?php if( $leftrightimage == 'imageleft' ) { ?>item-right<?php } ?> <?php if( $leftrightimage == 'imageright' ) { ?>item-left<?php } ?> width-7 absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="<?php if( $leftrightimage == 'imageleft' ) { ?>slide-left<?php } ?><?php if( $leftrightimage == 'imageright' ) { ?>slide-right<?php } ?>"></div>
                    <div class="<?php if( $leftrightimage == 'imageleft' ) { ?>item-right<?php } ?> <?php if( $leftrightimage == 'imageright' ) { ?>item-left<?php } ?>  width-3 absolute" data-aos-delay="75" data-aos-duration="500" data-aos-offset="50" data-aos="<?php if( $leftrightimage == 'imageleft' ) { ?>slide-left<?php } ?><?php if( $leftrightimage == 'imageright' ) { ?>slide-right<?php } ?>"></div>
                    <div class="<?php if( $leftrightimage == 'imageleft' ) { ?>item-right<?php } ?> <?php if( $leftrightimage == 'imageright' ) { ?>item-left<?php } ?> width-10 absolute" data-aos-delay="100" data-aos-duration="500" data-aos-offset="50" data-aos="<?php if( $leftrightimage == 'imageleft' ) { ?>slide-left<?php } ?><?php if( $leftrightimage == 'imageright' ) { ?>slide-right<?php } ?>"></div>

                    <img src="<?php echo $image ?>" />
        
                    <div class="<?php if( $leftrightimage == 'imageleft' ) { ?>item-left<?php } ?> <?php if( $leftrightimage == 'imageright' ) { ?>item-right<?php } ?> width-10 bottom-no-offset absolute" data-aos-delay="125" data-aos-duration="500" data-aos-offset="50" data-aos="<?php if( $leftrightimage == 'imageleft' ) { ?>slide-right<?php } ?><?php if( $leftrightimage == 'imageright' ) { ?>slide-left<?php } ?>"></div>
                </div>

                <div class="content no-min-height-mobile no-padding-bottom-mobile" style="padding-bottom:35px;">
                    <div class="text-section">
                        <h3><?php echo $name ?></h3>
                        <h5 style="margin-bottom:30px;"><?php echo $jobtitle ?></h5>
                        <?php echo $description ?>

                        <?php if( $addabutton == 'yes' ) { ?>
                            <div class="btn" onclick="founderPopup()" style="cursor:pointer;margin-bottom:30px;"><span class="text-bg"></span><span class="text"><?php echo $buttontext ?></span></div>
                        <?php } ?>
                    </div>
                </div>
            </section>

            <div class="founder-popup" id="popup">
                <span class="close" onclick="founderPopup()"><i class="fas fa-times"></i></span>
                    <p>I set up this business because I love the process of digital marketing and the creativity of commercial interiors.</p>

                    <p>But more importantly, I love working with people that are passionate about what they do.</p>

                    <p>Great relationships make for great work. My aim, always, is to do great work, for people that I love working with.</p>
            </div>


        <?php 

        // ======== Contact Form ========

            elseif( get_row_layout() == 'contact_form' ): 
                $officeaddress = get_sub_field('field_61d45d2cace47');
        ?>

            <section class="full-width-wrap contact-form">

            <?php echo do_shortcode( '[contact-form-7 id="387" title="Contact form 1"]' ); ?>

            <h3 style="margin-bottom:30px;">Our Offices:</h3>
            <?php echo $officeaddress ?>

            </section>

        <?php 

        // ======== Google Map ========

            elseif( get_row_layout() == 'google_map' ): 
        ?>

            <section class="full-width-wrap map" style="padding-top:0;">

            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9496.282857016608!2d-2.226146!3d53.4850663!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc5811bb8d8159a4d!2sList%20%26%20Found!5e0!3m2!1sen!2suk!4v1641394226040!5m2!1sen!2suk" height="450" style="border:0;width:100%;" allowfullscreen="" loading="lazy"></iframe>

            </section>


        <?php 

        // ======== Full Width Gallery========

            elseif( get_row_layout() == 'gallery_slider' ): 
                $title = get_sub_field('field_622b329a91fab');
        ?>

            <section class="slider-wrap gallery">

                <div class="item-right width-7 top-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                <div class="item-left width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-right"></div>
                    
                <div class="slider-background-wrap">  

                    <?php if( $title ): ?>
                        <h3><?php echo $title ?></h3>
                    <?php endif; ?>

                    <?php if( have_rows('slides') ): ?>
                        <div class="slider-gallery">
                        
                        <?php while( have_rows('slides') ): the_row();
                            $backgroundimage = get_sub_field('field_622b329a91fae');
                        ?>
        
                            <div style="background-image:linear-gradient(to right, rgba(255,255,255, 1), rgba(255,255,255, 0)), url(<?php echo $backgroundimage ?>);"></div>
        
                        <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div>     

                <div class="item-right width-8 bottom-no-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="0" data-aos="slide-left"></div>
                <div class="item-left width-3 bottom-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="0" data-aos="slide-right"></div>
                            
            </section>

            <?php 

            // ======== Accordion ========

                elseif( get_row_layout() == 'accordion' ): 
                    $title = get_sub_field('field_66ab5eb207584');
            ?>

                <section class="full-width-wrap text-unset">

                    <?php if( $title ): ?>
                        <h3><?php echo $title ?></h3>
                    <?php endif; ?>

                    <div>
                        <?php if( have_rows('blocks') ): ?>
                            <div class="block-test">
                            
                                <?php while( have_rows('blocks') ): the_row();
                                    $accordionTitle = get_sub_field('field_66ab5f2407586');
                                    $accordionContent = get_sub_field('field_66ab5f3107587');
                                ?>

                                    <div class="accordion">
                                        <p><?php echo $accordionTitle ?></p>
                                    </div>

                                    <div class="panel">
                                        <p><?php echo $accordionContent ?></p>
                                    </div>
                                   
                                <?php endwhile; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                </section>


        <?php 
        // ======== Random case studies ========

        elseif( get_row_layout() == 'random_case_study' ): 

            // Define the case studies
            $case_studies = [
                [
                    'image' => 'https://www.listandfound.co.uk/wp-content/smush-webp/2022/01/HumanBuilt.jpg.webp',
                    'buttonlink' => '/work/',
                    'titlelink' => '/work/',
                    'title' => 'HumanBuilt',
                    'excerpt' => 'Building 6-figure project win"s & 100x ROI from SEO & PPC.',
                    'buttontext' => 'Read More'
                ],
                [
                    'image' => 'https://www.listandfound.co.uk/wp-content/smush-webp/2022/01/Walker-Sime.jpg.webp',
                    'buttonlink' => '/work/',
                    'titlelink' => '/work/',
                    'title' => 'Walker Sime',
                    'excerpt' => 'From nowhere to #1: our perfectly constructed SEO campaign.',
                    'buttontext' => 'Read More'
                ],
                [
                    'image' => 'https://www.listandfound.co.uk/wp-content/smush-webp/2022/01/Caleo.jpg.webp',
                    'buttonlink' => '/work/',
                    'titlelink' => '/work/',
                    'title' => 'Caleo',
                    'excerpt' => 'Doubling enquiries and traffic in 3 months by focusing on the details.',
                    'buttontext' => 'Read More'
                ],
                [
                    'image' => 'https://www.listandfound.co.uk/wp-content/smush-webp/2022/01/Unibox-2.jpg.webp',
                    'buttonlink' => '/work/',
                    'titlelink' => '/work/',
                    'title' => 'Unibox',
                    'excerpt' => '317% increase in enquiries & #1 rankings across an entire industry.',
                    'buttontext' => 'Read More'
                ]
            ];

            // Select a random case study
            $random_index = array_rand($case_studies);
            $selected_case_study = $case_studies[$random_index];

            // Assign case study variables
            $image = $selected_case_study['image'];
            $buttonlink = $selected_case_study['buttonlink'];
            $titlelink = $selected_case_study['titlelink'];
            $title = $selected_case_study['title'];
            $excerpt = $selected_case_study['excerpt'];
            $buttontext = $selected_case_study['buttontext'];
        ?>
            <section class="grid image-left">
                <div class="image" style="background-image:url(<?php echo esc_url($image); ?>);"></div>
                
                <div class="content" style="<?php echo $buttonlink ? '' : 'padding-top:200px;padding-bottom:200px;'; ?>">
                    <div class="item-right width-1 top-inner absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                    <div class="text-section">
                        <h5>Case Study:</h5>
                        <h3><a href="<?php echo esc_url($titlelink); ?>"><?php echo esc_html($title); ?></a></h3>
                        <p style="margin-top:30px; font-size: 22px; line-height: 26px;" ><?php echo esc_html($excerpt); ?></p>

                        <?php if ($buttonlink): ?>
                            <a href="<?php echo esc_url($buttonlink); ?>" class="btn"><span class="text-bg"></span><span class="text"><?php echo esc_html($buttontext); ?></span></a>
                        <?php endif; ?>
                    </div>

                    <div class="item-right width-12 bottom-offset absolute" data-aos-delay="50" data-aos-duration="500" data-aos-offset="50" data-aos="slide-left"></div>
                </div>
            </section>


        <?php endif; ?>
    <?php endwhile; ?>
<?php endif; ?>
