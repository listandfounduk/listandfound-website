<?php
/* =================================================================
The template for displaying home page
================================================================= */
get_header();
?>

<?php include "template-parts/page-builder.php" ?>

<?php
get_footer();